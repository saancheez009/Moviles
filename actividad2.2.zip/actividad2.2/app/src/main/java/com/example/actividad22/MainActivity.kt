
package com.example.actividad22

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.example.actividad22.databinding.ActivityMainBinding
import com.example.actividad22.databinding.CalculadoraBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val MainBinding = ActivityMainBinding.inflate(layoutInflater)
        val calculadoraBinding = CalculadoraBinding.inflate(layoutInflater)

        setContentView(MainBinding.root)

        val botonAcceder = MainBinding.accederBoton

        val usuario = MainBinding.usuariotxt

        val contraseña = MainBinding.contraTxt

        var soluc: Double = 0.0


        //Acceder a calculadora
        botonAcceder.setOnClickListener(View.OnClickListener {
            if(usuario.text.toString() == "britany" && contraseña.text.toString() == "ciruela"){
                setContentView(calculadoraBinding.root)


            }else{
                Toast.makeText(this,"Contraseña o usuario incorrecto", Toast.LENGTH_SHORT).show()
            }
        })

        //Volver al main
        calculadoraBinding.backBoton.setOnClickListener(View.OnClickListener {
            setContentView(MainBinding.root)
        })

        calculadoraBinding.sumaBoton.setOnClickListener(View.OnClickListener {
        soluc = (calculadoraBinding.num1.text.toString().toDouble())+(calculadoraBinding.num2.text.toString().toDouble())
        calculadoraBinding.solucion.text = soluc.toString()
        })


        calculadoraBinding.restaBoton.setOnClickListener(View.OnClickListener {
            soluc = (calculadoraBinding.num1.text.toString().toDouble())-(calculadoraBinding.num2.text.toString().toDouble())
            calculadoraBinding.solucion.text = soluc.toString()
        })


        calculadoraBinding.multiBoton.setOnClickListener(View.OnClickListener {
            soluc = (calculadoraBinding.num1.text.toString().toDouble())*(calculadoraBinding.num2.text.toString().toDouble())
            calculadoraBinding.solucion.text = soluc.toString()
        })


        calculadoraBinding.divBoton.setOnClickListener(View.OnClickListener {
            //if(nulos()==true) {
                soluc = (calculadoraBinding.num1.text.toString().toDouble()) / (calculadoraBinding.num2.text.toString().toDouble())
                calculadoraBinding.solucion.text = soluc.toString()
           // }else{
            //    setContentView(calculadoraBinding.root)
              //  Toast.makeText(this,"No es posible realizar la operación", Toast.LENGTH_SHORT).show()
           // }
        })

    }
    //Comprobamos si el usuario introduce números
    private fun nulos(): Boolean {
        val calculadoraBinding = CalculadoraBinding.inflate(layoutInflater)
        var num1 = calculadoraBinding.num1.text.toString().toDouble()
        var num2 = calculadoraBinding.num2.text.toString().toDouble()
        var nulo: Boolean = true
        if (num1 == null || num1 == 0.0){
            num1 = 0.0
            nulo = false
        }else if (num2 == null || num2 == 0.0){
            num2 = 0.0
            nulo = false
        }
        return nulo
    }
}
