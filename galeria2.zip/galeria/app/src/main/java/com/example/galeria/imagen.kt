package com.example.galeria

data class Imagen ( val imagenUrl: String, val titulo: String
)