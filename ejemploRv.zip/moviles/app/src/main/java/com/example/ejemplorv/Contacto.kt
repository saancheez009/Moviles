package com.example.ejemplorv

data class Contacto (val nombre:String, val telefono:String){

}