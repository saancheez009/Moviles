package com.example.ejemplorv

import android.media.Image

data class Contacto (val nombre:String, val telefono:String){

}